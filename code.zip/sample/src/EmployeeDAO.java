import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    private static final String DATABASE_NAME = "employees";
    private static final String COLLECTION_NAME = "employeeDetails";
    private static MongoClient mongoClient = null;
    private static MongoDatabase mongoDatabase = null;
    private static MongoCollection<Document> mongoCollection = null;

    static {
        try {
            // Set up the MongoDB client
            MongoClientURI uri = new MongoClientURI("mongodb://localhost:27017");
            mongoClient = new MongoClient(uri);
            mongoDatabase = mongoClient.getDatabase(DATABASE_NAME);
            mongoCollection = mongoDatabase.getCollection(COLLECTION_NAME);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addEmployee(String id, String name, String age, String department) {
        try {
            // Create a new document
            Document document = new Document();
            document.append("id", id);
            document.append("name", name);
            document.append("age", age);
            document.append("department", department);

            // Insert the document into the collection
            mongoCollection.insertOne(document);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateEmployee(String id, String name, String age, String department) {
        try {
            // Find the document with the given ID and update its fields
            Document query = new Document("id", id);
            Document update = new Document("$set", new Document("name", name).append("age", age).append("department", department));
            mongoCollection.updateOne(query, update);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteEmployee(String id) {
        try {
            // Delete the document with the given ID
            Document query = new Document("id", id);
            mongoCollection.deleteOne(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<Employee> getEmployees() {
        List<Employee> employees = new ArrayList<>();
        try {
            // Retrieve all documents from the collection and convert them to Employee objects
            for (Document document : mongoCollection.find()) {
                String id = document.getString("id");
                String name = document.getString("name");
                String age = document.getString("age");
                String department = document.getString("department");
                Employee employee = new Employee(id, name, age, department);
                employees.add(employee);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employees;
    }
}

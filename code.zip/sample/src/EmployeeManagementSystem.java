import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.io.*;

public class EmployeeManagementSystem extends JFrame {
    private JLabel idLabel;
    private JTextField idField;
    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel ageLabel;
    private JTextField ageField;
    private JLabel departmentLabel;
    private JTextField departmentField;
    private JButton addButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JButton viewButton;
    private JTextArea area;
    private JButton clear;
    String temp_str_file="";
    public EmployeeManagementSystem() {
        // Set up the window
        setTitle("Employee Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1920, 1080);
        addButton = new JButton("Add Employee");
        addButton.setBounds(50,250,200,20);
        updateButton = new JButton("Update Employee");
        updateButton.setBounds(500,250,200,20);
        deleteButton = new JButton("Delete Employee");
        deleteButton.setBounds(50,300,200,20);
        viewButton = new JButton("View Employees");
        viewButton.setBounds(500,300,200,20);
        area=new JTextArea();
        area.setBounds(900,150,350,250);
        clear =new JButton("Clear");
        clear.setBounds(900,450,100,20);
        // Add the components to the window
        Color color=new Color(255,239,213);
        getContentPane().setBackground(color);
        add(addButton);
        add(updateButton);
        add(deleteButton);
        add(viewButton);
        JButton file_Button = new JButton("File");
        file_Button.setBounds(1050,450,100,20);
        Calendar cdr_objCalendar = Calendar.getInstance();
        JLabel cdr = new JLabel("Form entered at "+cdr_objCalendar.getTime());
        cdr.setBounds(50,600,400,25);
        cdr.setFont(new Font("Verdana",Font.PLAIN,15));
        // Add action listeners to the buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame addframe= new JFrame("Adding Employee");
                idLabel = new JLabel("ID:");
                idLabel.setBounds(50,50,100,20);
                idField = new JTextField();
                idField.setBounds(170,50,100,20);
                nameLabel = new JLabel("Name:");
                nameLabel.setBounds(50,100,100,20);
                nameField = new JTextField();
                nameField.setBounds(170,100,100,20);
                ageLabel = new JLabel("Age:");
                ageLabel.setBounds(50,200,100,20);
                ageField = new JTextField();
                ageField.setBounds(170,150,100,20);
                departmentLabel = new JLabel("Department:");
                departmentLabel.setBounds(50,150,100,20);
                departmentField = new JTextField();
                departmentField.setBounds(170,200,100,20);
                addframe.add(idLabel);
                addframe.add(idField);
                addframe.add(nameLabel);
                addframe.add(nameField);
                addframe.add(ageLabel);
                addframe.add(ageField);
                addframe.add(departmentLabel);
                addframe.add(departmentField);
                addframe.setLayout(null);
                addframe.setVisible(true);
                addframe.setSize(600,400);
                JButton added=new JButton("Add");
                added.setBounds(50,250,75,20);
                addframe.add(added);
                Color color=new Color(147, 236, 215);
                addframe.getContentPane().setBackground(color);
                added.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e)
                    {
                        String id = idField.getText();
                        String name = nameField.getText();
                        String age = ageField.getText();
                        String department = departmentField.getText();
                        EmployeeDAO.addEmployee(id, name, age, department);
                        JOptionPane.showMessageDialog(null, "Employee added successfully!");
                        addframe.setVisible(false);

                    }

                });
            }
        });

        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame updateframe=new JFrame("Updating Employees");

                idLabel = new JLabel("ID:");
                idLabel.setBounds(50,50,100,20);
                idField = new JTextField();
                idField.setBounds(170,50,100,20);
                nameLabel = new JLabel("Name:");
                nameLabel.setBounds(50,100,100,20);
                nameField = new JTextField();
                nameField.setBounds(170,100,100,20);
                ageLabel = new JLabel("Age:");
                ageLabel.setBounds(50,200,100,20);
                ageField = new JTextField();
                ageField.setBounds(170,150,100,20);
                departmentLabel = new JLabel("Department:");
                departmentLabel.setBounds(50,150,100,20);
                departmentField = new JTextField();
                departmentField.setBounds(170,200,100,20);
                updateframe.add(idLabel);
                updateframe.add(idField);
                updateframe.add(nameLabel);
                updateframe.add(nameField);
                updateframe.add(ageLabel);
                updateframe.add(ageField);
                updateframe.add(departmentLabel);
                updateframe.add(departmentField);
                updateframe.setLayout(null);
                updateframe.setVisible(true);
                updateframe.setSize(600,400);
                JButton updated=new JButton("Update");
                updated.setBounds(50,250,75,20);
                updateframe.add(updated);
                Color color=new Color(223, 155, 239);
                updateframe.getContentPane().setBackground(color);
                updated.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        String id = idField.getText();
                        String name = nameField.getText();
                        String age = ageField.getText();
                        String department = departmentField.getText();
                        EmployeeDAO.updateEmployee(id, name, age, department);
                        JOptionPane.showMessageDialog(null, "Employee updated successfully!");
                        updateframe.setVisible(false);
                    }
                }
                );
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame deleteframe=new JFrame("Deleting Employees");
                idLabel = new JLabel("Enter the unique ID to delete:");
                idLabel.setBounds(50,50,400,20);
                idField = new JTextField();
                idField.setBounds(300,50,100,20);
                deleteframe.add(idLabel);
                deleteframe.add(idField);
                deleteframe.setLayout(null);
                deleteframe.setVisible(true);
                deleteframe.setSize(600,400);
                JButton deleted=new JButton("Delete");
                deleted.setBounds(50,250,75,20);
                deleteframe.add(deleted);
                Color color=new Color(238, 143, 165);
                deleteframe.getContentPane().setBackground(color);
                deleted.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e){
                        String id = idField.getText();
                        EmployeeDAO.deleteEmployee(id);
                        JOptionPane.showMessageDialog(null, "Employee deleted successfully!");
                        deleteframe.setVisible(false);
                    }
                });
            }
        });
        viewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                List<Employee> employees = EmployeeDAO.getEmployees();
                if (employees.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No employees found!");
                } else {
                    String message = "ID\tName\tAge\tDepartment\n";
                    for (Employee employee : employees) {
                        message += employee.getId() + "\t" + employee.getName() + "\t" + employee.getAge() + "\t" + employee.getDepartment() + "\n";
                    }
                    add(area);
                    area.setText(message);
                    String temp=message;
                    add(clear);
                    add(file_Button);
                    clear.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e){
                         area.setVisible(false);
                         clear.setVisible(false);
                         file_Button.setVisible(false);
                        }
                    });
                    file_Button.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                            File out_file = new File("OUTFILE.txt");
                            try{
                                FileWriter fstream = new FileWriter("OUTFILE.txt",true);
                                BufferedWriter out =new BufferedWriter(fstream);
                                out.write("\nAt "+cdr_objCalendar.getTime()+":\n"+temp_str_file);
                                out.write(temp);
                                out.write("------------------------------------------------------------\n\n");
                                out.close();
                            }
                            catch(Exception e_obj){
                                System.err.println("Error in file writing : "+e_obj.getMessage());
                            }
                            clear.setVisible(false);
                            file_Button.setVisible(false);
                            area.setVisible(false);
                        }
                    });
                }
            }
        });
    }

    public static void main(String[] args) {
        EmployeeManagementSystem empSystem = new EmployeeManagementSystem();
        empSystem.setLayout(null);
        empSystem.setVisible(true);
    }
}
